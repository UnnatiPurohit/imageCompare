<template>
  <div>
    <ImageCompar />
  </div>
</template>

<script>
import ImageCompar from "@/components/imageCompare/ImageComparisonList";

export default {
  components: {
    ImageCompar,
  },
};
</script>